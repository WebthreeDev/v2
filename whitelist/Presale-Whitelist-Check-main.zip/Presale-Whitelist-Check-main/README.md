# Presale-Whitelist-Check
 
Macaron Token Presale Whitelist result check page.

You can check your address from here 👉
https://whitelist.macaronswap.finance/
